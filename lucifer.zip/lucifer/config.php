﻿<?php
#####################
#Connection Database#
#####################
$dbhost = "localhost";
$dbname = "lucifer";
$dbuser = "root";
$dbpass = "";
mysql_connect($dbhost,$dbuser,$dbpass) or  die(mysql_error());
mysql_select_db($dbname) or die(mysql_error());
@mysql_query("SET character_set_server='utf-8'; ");   
@mysql_query("SET NAMES 'utf8' COLLATE 'utf-8' ");   
@mysql_query("SET character_set_server='utf8'; ");   
@mysql_query("SET character_set_client='utf8'; ");   
@mysql_query("SET character_set_results='utf8'; ");   
@mysql_query("SET character_set_connection='utf8'; ");   
@mysql_query("SET character_set_database='utf8'; ");   
@mysql_query("SET collation_connection='utf8_unicode_ci'; ");   
@mysql_query("SET collation_database='utf8_unicode_ci'; ");  	
?>